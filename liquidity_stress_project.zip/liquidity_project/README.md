# Liquidity Risk & Cash Flow Stress Testing

Simple data science project in Python and R.

## What it does
1. Generates a synthetic bank balance sheet and 2 years of daily cash flows.
2. Calculates the Liquidity Coverage Ratio (LCR = HQLA / net 30-day outflows) under Base, Mild and Severe stress.
3. Runs a 10,000-path Monte Carlo of 30-day cash flows to estimate 95% VaR and probability of running out of cash.
4. Saves result tables (CSV) and charts (PNG) to `outputs/`.

## Run (from the project root folder)
    pip install pandas numpy matplotlib
    python python/01_generate_data.py
    python python/02_stress_test.py
    Rscript R/stress_test.R        # base R only, no packages needed

## Change the assumptions
Edit `scenarios` at the top of either stress-test script (runoff multiplier, haircut add-on, inflow multiplier).
