"""Step 2: LCR, scenario stress tests, and Monte Carlo cash flow simulation."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

np.random.seed(1)
assets = pd.read_csv("data/assets.csv")
liab = pd.read_csv("data/liabilities.csv")
inflows = pd.read_csv("data/inflows.csv")
cf = pd.read_csv("data/daily_cashflows.csv", parse_dates=["date"])

# ---- Scenarios: multipliers applied to the base case ----
scenarios = {
    "Base":   {"runoff_mult": 1.0, "haircut_add": 0.00, "inflow_mult": 1.0},
    "Mild":   {"runoff_mult": 1.5, "haircut_add": 0.05, "inflow_mult": 0.9},
    "Severe": {"runoff_mult": 2.5, "haircut_add": 0.15, "inflow_mult": 0.7},
}

def calc_lcr(s):
    # HQLA after haircuts (haircut is stressed up, capped at 100%)
    is_hqla = assets["hqla_level"] != "None"
    h = (assets["haircut"] + s["haircut_add"]).clip(upper=1.0)
    hqla = (assets.loc[is_hqla, "amount"] * (1 - h[is_hqla])).sum()

    outflow = (liab["amount"] * (liab["runoff_rate"] * s["runoff_mult"]).clip(upper=1.0)).sum()
    inflow = (inflows["amount"] * inflows["inflow_rate"] * s["inflow_mult"]).sum()
    inflow = min(inflow, 0.75 * outflow)      # Basel cap: inflows max 75% of outflows

    net_out = outflow - inflow
    return {"HQLA": hqla, "Outflows": outflow, "Inflows": inflow,
            "Net Outflow": net_out, "LCR %": 100 * hqla / net_out}

results = pd.DataFrame({name: calc_lcr(s) for name, s in scenarios.items()}).T.round(1)
results["Pass (>=100%)"] = results["LCR %"] >= 100
print("\n=== LCR Stress Test ===")
print(results)
results.to_csv("outputs/py_lcr_results.csv")

# ---- Monte Carlo: 30-day cumulative net cash flow ----
mu, sigma = cf["net_flow"].mean(), cf["net_flow"].std()
n_sims, horizon = 10000, 30
opening_cash = assets.loc[assets["item"] == "Cash", "amount"].iloc[0]

mc = {}
for name, s in scenarios.items():
    # stressed: lower mean, higher volatility
    m = mu - (s["runoff_mult"] - 1) * 2
    sd = sigma * s["runoff_mult"] ** 0.5
    paths = np.random.normal(m, sd, (n_sims, horizon)).cumsum(axis=1)
    mc[name] = paths
    final = paths[:, -1]
    prob_short = (opening_cash + final < 0).mean() * 100
    var95 = np.percentile(final, 5)
    print(f"{name:7s} | 30d 95% VaR of net flow: {var95:8.1f} | P(cash < 0): {prob_short:5.1f}%")

# ---- Charts ----
fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
ax[0].bar(results.index, results["LCR %"], color=["green", "orange", "red"])
ax[0].axhline(100, color="black", ls="--", label="Regulatory min 100%")
ax[0].set_title("LCR by Scenario"); ax[0].set_ylabel("LCR %"); ax[0].legend()

for name, c in zip(mc, ["green", "orange", "red"]):
    ax[1].hist(mc[name][:, -1], bins=60, alpha=0.5, color=c, label=name)
ax[1].axvline(-opening_cash, color="black", ls="--", label="Cash exhausted")
ax[1].set_title("Monte Carlo: 30-day cumulative net cash flow")
ax[1].set_xlabel("$ millions"); ax[1].legend()
plt.tight_layout()
plt.savefig("outputs/py_stress_charts.png", dpi=120)
print("\nSaved outputs/py_lcr_results.csv and outputs/py_stress_charts.png")
