"""Step 1: create simple synthetic data (balance sheet + 2 years of daily cash flows)."""
import numpy as np
import pandas as pd

np.random.seed(42)

# ---- Balance sheet (amounts in $ millions) ----
assets = pd.DataFrame({
    "item":    ["Cash", "Government Bonds", "Corporate Bonds AA", "Equities", "Loans"],
    "amount":  [200, 400, 150, 80, 1500],
    "hqla_level": ["L1", "L1", "L2A", "L2B", "None"],
    "haircut": [0.00, 0.00, 0.15, 0.50, 1.00],   # 1.00 = not liquid
})

liabilities = pd.DataFrame({
    "item":     ["Retail Stable Deposits", "Retail Less-Stable Deposits",
                 "Wholesale Operational", "Wholesale Non-Operational"],
    "amount":   [900, 500, 400, 300],
    "runoff_rate": [0.03, 0.10, 0.25, 0.40],      # 30-day outflow rate
})

inflows = pd.DataFrame({
    "item": ["Loan Repayments (30d)", "Interbank Lending (30d)"],
    "amount": [120, 60],
    "inflow_rate": [0.50, 0.50],
})

assets.to_csv("data/assets.csv", index=False)
liabilities.to_csv("data/liabilities.csv", index=False)
inflows.to_csv("data/inflows.csv", index=False)

# ---- Daily cash flows for 730 days ----
days = pd.date_range("2023-01-01", periods=730, freq="D")
inflow = np.random.normal(30, 4, len(days))       # daily cash in
outflow = np.random.normal(29, 5, len(days))      # daily cash out
# add a few random "shock" days with large withdrawals
shock_days = np.random.choice(len(days), 12, replace=False)
outflow[shock_days] += np.random.uniform(15, 40, 12)

cf = pd.DataFrame({"date": days, "inflow": inflow, "outflow": outflow})
cf["net_flow"] = cf["inflow"] - cf["outflow"]
cf.to_csv("data/daily_cashflows.csv", index=False)

print("Data created in /data:", len(assets), "assets,", len(liabilities), "liabilities,", len(cf), "daily rows")
