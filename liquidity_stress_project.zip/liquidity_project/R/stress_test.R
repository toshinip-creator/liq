# Liquidity stress test in R (base R only - no packages needed)
set.seed(1)

assets   <- read.csv("data/assets.csv")
liab     <- read.csv("data/liabilities.csv")
inflows  <- read.csv("data/inflows.csv")
cf       <- read.csv("data/daily_cashflows.csv")

# ---- Scenarios ----
scenarios <- list(
  Base   = list(runoff_mult = 1.0, haircut_add = 0.00, inflow_mult = 1.0),
  Mild   = list(runoff_mult = 1.5, haircut_add = 0.05, inflow_mult = 0.9),
  Severe = list(runoff_mult = 2.5, haircut_add = 0.15, inflow_mult = 0.7)
)

calc_lcr <- function(s) {
  is_hqla <- assets$hqla_level != "None"
  h       <- pmin(assets$haircut + s$haircut_add, 1)
  hqla    <- sum(assets$amount[is_hqla] * (1 - h[is_hqla]))

  outflow <- sum(liab$amount * pmin(liab$runoff_rate * s$runoff_mult, 1))
  inflow  <- sum(inflows$amount * inflows$inflow_rate * s$inflow_mult)
  inflow  <- min(inflow, 0.75 * outflow)      # Basel cap

  net_out <- outflow - inflow
  c(HQLA = hqla, Outflows = outflow, Inflows = inflow,
    NetOutflow = net_out, LCR_pct = 100 * hqla / net_out)
}

res_mat <- round(t(sapply(scenarios, calc_lcr)), 1)
results <- data.frame(res_mat, Pass = res_mat[, "LCR_pct"] >= 100)
cat("\n=== LCR Stress Test ===\n")
print(results)
write.csv(results, "outputs/r_lcr_results.csv")

# ---- Monte Carlo: 30-day cumulative net cash flow ----
mu      <- mean(cf$net_flow)
sigma   <- sd(cf$net_flow)
n_sims  <- 10000
horizon <- 30
opening_cash <- assets$amount[assets$item == "Cash"]

mc_final <- list()
for (name in names(scenarios)) {
  s  <- scenarios[[name]]
  m  <- mu - (s$runoff_mult - 1) * 2
  stdev <- sigma * sqrt(s$runoff_mult)
  daily <- matrix(rnorm(n_sims * horizon, m, stdev), nrow = n_sims)
  final <- rowSums(daily)                      # 30-day cumulative net flow
  mc_final[[name]] <- final
  cat(sprintf("%-7s | 30d 95%% VaR of net flow: %8.1f | P(cash < 0): %5.1f%%\n",
              name, quantile(final, 0.05), 100 * mean(opening_cash + final < 0)))
}

# ---- Charts ----
png("outputs/r_stress_charts.png", width = 1200, height = 450, res = 110)
par(mfrow = c(1, 2))
barplot(res_mat[, "LCR_pct"], names.arg = rownames(res_mat),
        col = c("green", "orange", "red"), main = "LCR by Scenario", ylab = "LCR %")
abline(h = 100, lty = 2)

rng    <- range(unlist(mc_final))
breaks <- seq(rng[1], rng[2], length.out = 61)
hist(mc_final$Base, breaks = breaks, col = rgb(0, 0.7, 0, 0.4),
     main = "Monte Carlo: 30-day net cash flow", xlab = "$ millions")
hist(mc_final$Mild,   breaks = breaks, add = TRUE, col = rgb(1, 0.6, 0, 0.4))
hist(mc_final$Severe, breaks = breaks, add = TRUE, col = rgb(1, 0, 0, 0.4))
abline(v = -opening_cash, lty = 2)
legend("topleft", legend = names(scenarios), fill = c("green", "orange", "red"), bty = "n")
invisible(dev.off())
cat("\nSaved outputs/r_lcr_results.csv and outputs/r_stress_charts.png\n")
